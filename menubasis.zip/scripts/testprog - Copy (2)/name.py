import os
print("Menu system, you can create anything here aslong as it dosen't break anything, i will probably break it, 'you will' - thom") 

programfolders = os.walk("scripts")
for x in programfolders:
    print(x[2])
print("#-------------------------------------------------------------------------------------------------------")






print("#-------------------------------------------------------------------------------------------------------")

